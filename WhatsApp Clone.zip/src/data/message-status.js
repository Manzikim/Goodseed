const MESSAGE_STATUS = {
    NOT_SENT: 0,
    SENT: 1,
    DELIVERED: 2,
    SEEN: 3
}
export default MESSAGE_STATUS;