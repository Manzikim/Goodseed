import React from 'react';
import './styles.css';

function Header(props) {
    const {contactData} = props;
    return contactData == null ? <h1>No Data</h1> : (
        <>
            <div className="container">

                <img src={contactData.profile} alt="" />

                <div className="contact-name">
                    <p>{contactData.name}</p>
                    <p>{contactData.date}</p>
                </div>

            </div>
        </>
    )
}

export default Header;