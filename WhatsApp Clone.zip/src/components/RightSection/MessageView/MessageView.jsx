import React from "react";
import Header from "../Header";

function MessageView(props) {
    return (
        <>
            <Header contactData={props.contactData} />
        </>
    )
}

export default MessageView;