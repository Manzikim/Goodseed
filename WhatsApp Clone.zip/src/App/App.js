import React, { useState } from 'react';
import MessageList from '../components/LeftSection/message-list/index';
import MessageView from '../components/RightSection/MessageView/MessageView';

function App() {
    const [contactData, setContactData] = useState({});
    const getData = (data) => {
        setContactData(data);
    }
    return(
        <>
            <MessageList giveData={getData} />
            <MessageView contactData={contactData} />
        </>
    )
}

export default App;