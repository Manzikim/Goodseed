import React, { useState } from "react";
import { BiAddToQueue } from 'react-icons/bi';
import { FaBandcamp } from 'react-icons/fa';
import { AiOutlineZoomIn } from 'react-icons/ai';

function CreateArea(props) {
  const [isExpanded, setExpanded] = useState(false);

  const [note, setNote] = useState({
    title: "",
    content: ""
  });

  function handleChange(event) {
    const { name, value } = event.target;

    setNote(prevNote => {
      return {
        ...prevNote,
        [name]: value
      };
    });
  }

  function submitNote(event) {
    props.onAdd(note);
    setNote({
      title: "",
      content: ""
    });
    event.preventDefault();
  }

  function expand() {
    setExpanded(true);
  }

  return (
    <div>
      <form className="create-note">
        {isExpanded && (
          <input
            name="title"
            onChange={handleChange}
            value={note.title}
            placeholder="Title"
          />
        )}

        <textarea
          name="content"
          onClick={expand}
          onChange={handleChange}
          value={note.content}
          placeholder="Take a note..."
          rows={isExpanded ? 3 : 1}
        />
        <AiOutlineZoomIn in={isExpanded}>
          <FaBandcamp onClick={submitNote}>
            <BiAddToQueue />
          </FaBandcamp>
        </AiOutlineZoomIn>
      </form>
    </div>
  );
}

export default CreateArea;
